package com.G.A.api_jugadores;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiJugadoresApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiJugadoresApplication.class, args);
	}

}
