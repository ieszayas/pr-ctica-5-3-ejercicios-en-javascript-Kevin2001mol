package com.G.A.api_jugadores;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiJugadoresApplicationTests {

	@Test
	void contextLoads() {
	}

}
