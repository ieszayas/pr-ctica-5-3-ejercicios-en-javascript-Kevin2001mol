package com.G.A.api_jugadores;  // Debes dejar esta declaración tal como está en tu archivo Java actual.

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiJugadoresApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApiJugadoresApplication.class, args);
	}

}
